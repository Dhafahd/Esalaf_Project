package com.jfoenix.controls.pannable;

public class PannablePane {
}
