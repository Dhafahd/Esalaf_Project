package com.example.esalaf2;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;

import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ResourceBundle;

public class ProduitController implements Initializable {


    @FXML
    private Button btnajouter;

    @FXML
    private Button btnmodifier;

    @FXML
    private Button btnsupprimer;

    @FXML
    private TableColumn<Produit,String> colbrand;

    @FXML
    private TableColumn<Produit,Integer> colid;

    @FXML
    private TableColumn<Produit,Float> colprix;

    @FXML
    private TableColumn<Produit,String> colproduit;

    @FXML
    private TextField tfbrande;

    @FXML
    private TextField tfid;

    @FXML
    private TextField tfprix;

    @FXML
    private TextField tfproduit;

    @FXML
    private TableView<Produit> tvbox;


        @Override
        public void initialize(URL url, ResourceBundle resourceBundle) {
            showclients();
        }

    public void OnAction(ActionEvent event) {
        if (event.getSource() == btnajouter){
            onAjouterButtClick();
        }else if (event.getSource() == btnmodifier) {
            onmodButtClick();
        }else if (event.getSource() == btnsupprimer ) {
            onsuppButtClick();
        }
    }

    public Connection getConnection(){
        Connection conn;
        try {
            conn = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/esalaf","root","");
            return conn;
        }catch (Exception ex){
            System.out.println("Error "+ ex.getMessage());
            return null;
        }
    }
    public ObservableList<Produit> getclientsListe(){
        ObservableList<Produit> ProduitsList = FXCollections.observableArrayList();
        Connection conn = getConnection();
        String req = "SELECT * FROM produit";
        Statement st;
        ResultSet rs;

        try{
            st = conn.createStatement();
            rs = st.executeQuery(req);
            Produit produits;
            while(rs.next()){
                produits = new Produit(rs.getInt("IdP")
                        ,rs.getString("NomBrande")
                        ,rs.getString("NomProduit")
                        ,rs.getFloat("Prix"));
                ProduitsList.add(produits);
            }
        }catch (Exception ex){
            ex.printStackTrace();
        }
        return ProduitsList;
    }
    public void showclients(){
        ObservableList<Produit> Liste = getclientsListe();
        colid.setCellValueFactory(new PropertyValueFactory<>("IdP"));
        colbrand.setCellValueFactory(new PropertyValueFactory<Produit,String>("NomBrande"));
        colproduit.setCellValueFactory(new PropertyValueFactory<Produit,String>("NomProduit"));
        colprix.setCellValueFactory(new PropertyValueFactory<Produit,Float>("Prix"));
        tvbox.setItems(Liste);
    }

    public void onAjouterButtClick(){
          String c="NULL";
        String req ="INSERT INTO produit VALUES ("+c +",'"+tfbrande.getText()+"','"+tfproduit.getText()+"',"+tfprix.getText()+")";
        executeQuery(req);
        showclients();
    }
    public void onmodButtClick(){
        String req = "UPDATE produit SET NomBrande = '" + tfbrande.getText() + "', NomProduit = '" + tfproduit.getText() + "', Prix= " + tfprix.getText() + " WHERE idP = " + tfid.getText() + "" ;
        executeQuery(req);
        showclients();
    }
    public void onsuppButtClick() {
        String req = "DELETE FROM produit WHERE IdP =" + tfid.getText() + "";
        executeQuery(req);
        showclients();
    }
    public void executeQuery(String req) {
        Connection conn = getConnection();
        Statement st;
        try{
            st = conn.createStatement();
            st.executeUpdate(req);
        }catch(Exception ex){
            ex.printStackTrace();
        }
    }
    public void onMouseClick(javafx.scene.input.MouseEvent mouseEvent) {
        Produit cli = tvbox.getSelectionModel().getSelectedItem();
        tfid.setText(""+cli.getIdP());
        tfproduit.setText(cli.getNomProduit());
        tfbrande.setText(cli.getNomBrande());
        tfprix.setText(""+cli.getPrix());
    }

}
