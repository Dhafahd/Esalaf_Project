package com.example.esalaf2;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;

import java.awt.event.MouseEvent;
import java.net.URL;
import java.sql.*;
import java.util.ArrayList;
import java.util.EventObject;
import java.util.List;
import java.util.ResourceBundle;
public class CommandeController implements Initializable {

    @FXML
    private Button btnajouter;

    @FXML
    private Button btnmodifier;

    @FXML
    private Button btnsupprimer;

    @FXML
    private TableColumn<Commande,String> colbrande;

    @FXML
    private TableColumn<Commande,Date> coldate;

    @FXML
    private TableColumn<Commande, Integer> colid;

    @FXML
    private TableColumn<Commande, String> colnom;

    @FXML
    private TableColumn<Commande, String> colproduit;

    @FXML
    private TableColumn<Commande, String> coltel;


    @FXML
    private TextField tfbrande;

    @FXML
    private DatePicker tfdate;

    @FXML
    private TextField tfid;

    @FXML
    private TextField tfnom;

    @FXML
    private TextField tfproduit;

    @FXML
    private TextField tftel;

    @FXML
    private TableView<Commande> tvbox;




    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        showclients();
    }

    public void OnAction(ActionEvent event) {
        if (event.getSource() == btnajouter){
            onAjouterButtClick();
        } else if (event.getSource() == btnmodifier) {
            onmodButtClick();
        } else if (event.getSource() == btnsupprimer ) {
            onsuppButtClick();
        }else if (event.getSource() == btnsupprimer ) {
            onsuppButtClick();
        }
    }
    public Connection getConnection(){
        Connection conn;
        try {
            conn = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/esalaf","root","");
            return conn;
        }catch (Exception ex){
            System.out.println("Error de connection"+ ex.getMessage());
            return null;
        }
    }

    public ObservableList<Commande> getcommandesListe(){
        ObservableList<Commande> CommandesList = FXCollections.observableArrayList();
        Connection conn = getConnection();
        String req = "SELECT * FROM commande";
        Statement st;
        ResultSet rs;

        try{
            st = conn.createStatement();
            rs = st.executeQuery(req);
            Commande commandes;
            while(rs.next()){
                commandes = new Commande(rs.getInt("IdCom")
                        ,rs.getString("Nomprenom")
                        ,rs.getString("Brande")
                        ,rs.getString("Produit")
                        ,rs.getString("Telephone")
                        ,rs.getDate("Date_commande"));
                CommandesList.add(commandes);
            }
        }catch (Exception ex){
            ex.printStackTrace();
        }
        return CommandesList;
    }
    public void showclients(){
        ObservableList<Commande> Liste = getcommandesListe();
        colid.setCellValueFactory(new PropertyValueFactory<>("IdCom"));
        colnom.setCellValueFactory(new PropertyValueFactory<Commande,String>("Nomprenom"));
        colbrande.setCellValueFactory(new PropertyValueFactory<Commande,String>("Brande"));
        colproduit.setCellValueFactory(new PropertyValueFactory<Commande,String>("Produit"));
        coltel.setCellValueFactory(new PropertyValueFactory<Commande,String>("Telephone"));
        coldate.setCellValueFactory(new PropertyValueFactory<Commande,Date>("Date_commande"));

        tvbox.setItems(Liste);
    }
    public void onAjouterButtClick(){
        String c="NULL";
        String req ="INSERT INTO commande VALUES ("+ c +",'"+tfnom.getText()+"','"+tfbrande.getText()+"','"+tfproduit.getText()+"','"+tftel.getText()+"','"+tfdate.getValue()+"')";
        executeQuery(req);
        showclients();
    }

    public void onmodButtClick(){
        String req = "UPDATE commande SET Nomprenom = '" + tfnom.getText() + "', Brande = '" + tfbrande.getText()+ "', Produit = '" + tfproduit.getText()+ "', Telephone = '" + tftel.getText()
                + "', Date_commande= '" + tfdate.getValue() + "' WHERE IdCom = " + tfid.getText() + "";
        executeQuery(req);
        showclients();
    }

    public void onsuppButtClick() {
        String req = "DELETE FROM commande WHERE IdCom =" + tfid.getText() + "";
        executeQuery(req);
        showclients();
    }

    public void executeQuery(String req) {
        Connection conn = getConnection();
        Statement st;
        try{
            st = conn.createStatement();
            st.executeUpdate(req);
        }catch(Exception ex){
            ex.printStackTrace();
        }
    }

    public void onMouseClick(javafx.scene.input.MouseEvent mouseEvent) {
        Commande pro = tvbox.getSelectionModel().getSelectedItem();
        tfid.setText("" + pro.getIdCom());
        tfnom.setText(pro.getNomprenom());
        tfproduit.setText(pro.getProduit());
        tfbrande.setText(pro.getBrande());
        tftel.setText(pro.getTelephone());
        tfdate.setValue(pro.getDate_commande().toLocalDate());

    }

}
