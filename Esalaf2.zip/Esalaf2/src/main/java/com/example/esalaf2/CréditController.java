package com.example.esalaf2;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;

import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ResourceBundle;

public class CréditController implements Initializable {

    @FXML
    private Button btnajouter;

    @FXML
    private Button btnmodifier;

    @FXML
    private TableColumn<Credit,Float> colcredit;

    @FXML
    private TableColumn<Credit,Integer> colid;

    @FXML
    private TableColumn<Credit,String> colnom;

    @FXML
    private TextField tfcredit;

    @FXML
    private TextField tfid;

    @FXML
    private TextField tfnom;

    @FXML
    private Button tfsupprimer;

    @FXML
    private TableView<Credit> tvbox;



    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        showclients();
    }

    public void OnAction(ActionEvent event) {
        if (event.getSource() == btnajouter){
            onAjouterButtClick();
        }else if (event.getSource() == btnmodifier) {
            onmodButtClick();
        }else if (event.getSource() == tfsupprimer ) {
            onsuppButtClick();
        }
    }


    public Connection getConnection(){
        Connection conn;
        try {
            conn = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/esalaf","root","");
            return conn;
        }catch (Exception ex){
            System.out.println("Error "+ ex.getMessage());
            return null;
        }
    }
    public ObservableList<Credit> getclientsListe(){
        ObservableList<Credit> CreditsList = FXCollections.observableArrayList();
        Connection conn = getConnection();
        String req = "SELECT * FROM credit";
        Statement st;
        ResultSet rs;

        try{
            st = conn.createStatement();
            rs = st.executeQuery(req);
            Credit credits;
            while(rs.next()){
                credits= new Credit(rs.getInt("IdCr")
                        ,rs.getString("Nomprenom")
                        ,rs.getFloat("Montant_Credit"));
                CreditsList.add(credits);
            }
        }catch (Exception ex){
            ex.printStackTrace();
        }
        return CreditsList;
    }
    public void showclients(){
        ObservableList<Credit> Liste = getclientsListe();
        colid.setCellValueFactory(new PropertyValueFactory<>("IdCr"));
        colnom.setCellValueFactory(new PropertyValueFactory<Credit,String>("Nomprenom"));
        colcredit.setCellValueFactory(new PropertyValueFactory<Credit,Float>("Montant_Credit"));
        tvbox.setItems(Liste);
    }
    public void onAjouterButtClick(){

        String c="NULL";
        String req ="INSERT INTO credit VALUES ("+ c +",'"+tfnom.getText()+"',"+tfcredit.getText()+")";
        executeQuery(req);
        showclients();
    }
    public void onmodButtClick(){
        String req = "UPDATE credit SET Nomprenom = '" + tfnom.getText() + "', Montant_Credit= " + tfcredit.getText() + " WHERE idCr = " + tfid.getText() + "" ;
        executeQuery(req);
        showclients();
    }
    public void onsuppButtClick() {
        String req = "DELETE FROM credit WHERE IdCr =" + tfid.getText() + "";
        executeQuery(req);
        showclients();
    }
    public void executeQuery(String req) {
        Connection conn = getConnection();
        Statement st;
        try{
            st = conn.createStatement();
            st.executeUpdate(req);
        }catch(Exception ex){
            ex.printStackTrace();
        }
    }

    public void onMouseClick(javafx.scene.input.MouseEvent mouseEvent) {
        Credit cli = tvbox.getSelectionModel().getSelectedItem();
        tfid.setText(""+cli.getIdCr());
        tfnom.setText(cli.getNomprenom());
        tfcredit.setText(""+cli.getMontant_Credit());
    }
}
