package com.example.esalaf2;

public class Client {

    private int IdC ;
    private String NomprenomC ;
    private String Cni ;
    private String Telephone ;

    public Client(int IdC, String NomprenomC, String Cni,String Telephone) {
        this.IdC = IdC;
        this.NomprenomC= NomprenomC;
        this.Telephone = Telephone;
        this.Cni = Cni;

    }

    public int getIdC() {
        return IdC;
    }
    public void setidC(int IdC) {
        this.IdC = IdC;
    }

    public String getNomprenomC() {
        return NomprenomC;
    }
    public void setNomprenomC(String NomprenomC) {
        this.NomprenomC = NomprenomC;
    }

    public String getTelephone() {
        return Telephone;
    }
    public void setTelephone(String Telephone) {
        this.Telephone = Telephone;
    }

    public String getCni() {
        return Cni;
    }
    public void setCni(String Cni) {
        this.Cni = Cni;
    }

    @Override
    public String toString() {
        return "Client{" +
                "idC=" + IdC +
                ", nomprenomC='" + NomprenomC + '\'' +
                ", telepehone='" + Telephone + '\'' +
                ", Cni='" + Cni + '\'' +
                '}';
    }
}


