package com.example.esalaf2;

public class Credit {
    private int IdCr;

    private String Nomprenom ;

    private Float Montant_Credit ;

    public Credit(int idP, String nomprenom, Float montant_Credit) {
        IdCr = idP;
        Nomprenom = nomprenom;
        Montant_Credit = montant_Credit;
    }

    public int getIdCr() {
        return IdCr;
    }

    public void setIdCr(int IdCr) {
        this.IdCr = IdCr;
    }

    public String getNomprenom() {
        return Nomprenom;
    }

    public void setNomprenom(String nomprenom) {
        Nomprenom = nomprenom;
    }

    public Float getMontant_Credit() {
        return Montant_Credit;
    }

    public void setMontant_Credit(Float montant_Credit) {
        Montant_Credit = montant_Credit;
    }
}
