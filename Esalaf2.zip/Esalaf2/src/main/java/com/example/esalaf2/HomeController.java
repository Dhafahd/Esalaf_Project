package com.example.esalaf2;


import com.dlsc.formsfx.model.structure.PasswordField;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;


import java.awt.event.ActionEvent;
import java.net.URL;
import java.util.ResourceBundle;


public class HomeController implements Initializable {

private Parent fxml;
	@FXML
	private AnchorPane root;


	public void produit(javafx.scene.input.MouseEvent mouseEvent) {
		try {
			fxml = FXMLLoader.load(getClass().getResource("Produit.fxml"));
			root.getChildren().removeAll();
			root.getChildren().setAll(fxml);
		}catch (Exception e){
			e.printStackTrace();
		}
	}


	public void client(javafx.scene.input.MouseEvent mouseEvent) {
		try {
			fxml = FXMLLoader.load(getClass().getResource("Client.fxml"));
			root.getChildren().removeAll();
			root.getChildren().setAll(fxml);
		}catch (Exception e){
			e.printStackTrace();
		}
		}

		public void commande(MouseEvent mouseEvent) {
			try {
				fxml = FXMLLoader.load(getClass().getResource("Commande.fxml"));
				root.getChildren().removeAll();
				root.getChildren().setAll(fxml);
			}catch (Exception e){
				e.printStackTrace();
			}
		}

	public void credit(MouseEvent mouseEvent) {
		try {
			fxml = FXMLLoader.load(getClass().getResource("crédit.fxml"));
			root.getChildren().removeAll();
			root.getChildren().setAll(fxml);
		}catch (Exception e){
			e.printStackTrace();
		}
	}

	@Override
	public void initialize(URL url, ResourceBundle resourceBundle) {

	}
}







