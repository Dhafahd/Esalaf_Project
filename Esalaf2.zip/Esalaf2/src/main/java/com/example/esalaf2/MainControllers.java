package com.example.esalaf2;




import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;


import java.io.IOException;
import java.net.URL;
import java.sql.*;
import java.util.ResourceBundle;



public class MainControllers implements Initializable {


	@Override
	public void initialize(URL url, ResourceBundle resourceBundle) {

	}

	@FXML
	private Button Conn;

	@FXML
	private TextField no;

	@FXML
	private PasswordField pass = new PasswordField();

	@FXML
	private Label text;


	public void ConnOnAction(javafx.event.ActionEvent actionEvent) {
		String nom = no.getText();
		String password = pass.getText();

		try (Connection conn = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/esalaf","root","")) {
			PreparedStatement stmt = conn.prepareStatement("SELECT * FROM admin WHERE userName=? AND password=?");
			stmt.setString(1,nom);
			stmt.setString(2,password);
			ResultSet rs = stmt.executeQuery();
			if (rs.next()) {
				Stage currentStage = (Stage) Conn.getScene().getWindow();
				Parent root = FXMLLoader.load(getClass().getResource("Home.fxml"));
				Scene scene = new Scene(root);
				currentStage.setScene(scene);
				currentStage.show();
			} else {
				text.setText("Error!");
				no.clear();
				pass.clear();
			}
		} catch (SQLException ex) {
			ex.printStackTrace();
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}
}
