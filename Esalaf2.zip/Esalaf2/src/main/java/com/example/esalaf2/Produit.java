package com.example.esalaf2;

public class Produit {

    private int IdP ;

    private String NomBrande ;

    private String NomProduit ;

    private Float Prix ;

    public Produit(int idP, String nomBrande, String nomProduit, Float prix) {
        this.IdP = idP;
        this.NomBrande = nomBrande;
        this.NomProduit = nomProduit;
        this.Prix = prix;
    }

    public int getIdP() {
        return IdP;
    }

    public String getNomBrande() {
        return NomBrande;
    }

    public String getNomProduit() {
        return NomProduit;
    }

    public Float getPrix() {
        return Prix;
    }

    public void setIdP(int idP) {
        IdP = idP;
    }

    public void setNomBrande(String nomBrande) {
        NomBrande = nomBrande;
    }

    public void setNomProduit(String nomProduit) {
        NomProduit = nomProduit;
    }

    public void setPrix(Float prix) {
        Prix = prix;
    }

}

