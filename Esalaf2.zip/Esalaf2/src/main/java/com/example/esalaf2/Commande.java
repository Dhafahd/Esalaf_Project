package com.example.esalaf2;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

public class Commande {
    private int IdCom ;

    private String Nomprenom ;
    private String Brande ;
    private String Telephone ;
    private String Produit ;
    private Date Date_commande ;

    public Commande(int idCom, String nomprenom, String brande, String telephone, String produit, Date date_commande) {
        IdCom = idCom;
        Nomprenom = nomprenom;
        Brande = brande;
        Telephone = telephone;
        Produit = produit;
        Date_commande = date_commande;
    }

    public int getIdCom() {
        return IdCom;
    }

    public void setIdCom(int idCom) {
        IdCom = idCom;
    }

    public String getNomprenom() {
        return Nomprenom;
    }

    public void setNomprenom(String nomprenom) {
        Nomprenom = nomprenom;
    }

    public String getBrande() {
        return Brande;
    }

    public void setBrande(String brande) {
        Brande = brande;
    }

    public String getTelephone() {
        return Telephone;
    }

    public void setTelephone(String telephone) {
        Telephone = telephone;
    }

    public String getProduit() {
        return Produit;
    }

    public void setProduit(String produit) {
        Produit = produit;
    }

    public Date getDate_commande() {
        return Date_commande;
    }

    public void setDate_commande(Date date_commande) {
        Date_commande = date_commande;
    }

    private String [] clientsListe = {"Youssef", "Ahmad"};


}
